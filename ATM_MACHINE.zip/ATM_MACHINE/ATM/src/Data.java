public class Data {
    public static double acbalance = 0, transAmount;
    public static int transactionID = 100;
    public static String transType, transStatus;
}
